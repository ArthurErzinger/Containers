#!/bin/bash
sudo make run